for i in range(100,9,-2):
    print(i, end=" ")