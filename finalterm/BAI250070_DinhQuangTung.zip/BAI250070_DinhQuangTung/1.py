n=int(input())
if n%2==0:
    print("la so chan")
else:
    print("la so le")
if n>0:
    for i in range(1,n+1):
        if i%2==0:
            print(i,end=" ")
else:
    print("n lon hon 0 moi trien khai danh sach so chan")
    
            
    
        