s=input()
sumt=0
for char in s:
    if char.isdigit():
       sumt+=1
print(f"co {sumt} ky tu so")
print(s.lower())

